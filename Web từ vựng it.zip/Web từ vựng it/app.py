from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = "ducvu_secret_key"

# =============================
# TẠO DATABASE
# =============================
def init_db():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT UNIQUE,
            password TEXT,
            role TEXT
        )
    """)

    conn.commit()
    conn.close()


# =============================
# TRANG CHÍNH (LOGIN + REGISTER)
# =============================
@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":

        # ================= REGISTER =================
        if "register" in request.form:
            name = request.form.get("name")
            email = request.form.get("email")
            password = request.form.get("password")
            role = request.form.get("role")

            conn = sqlite3.connect("database.db")
            cursor = conn.cursor()

            try:
                cursor.execute(
                    "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
                    (name, email, password, role)
                )
                conn.commit()
                conn.close()
                return "Đăng ký thành công! Hãy login lại."

            except:
                conn.close()
                return "Email đã tồn tại!"

        # ================= LOGIN =================
        if "login" in request.form:
            email = request.form.get("email")
            password = request.form.get("password")

            conn = sqlite3.connect("database.db")
            cursor = conn.cursor()

            cursor.execute(
                "SELECT * FROM users WHERE email=? AND password=?",
                (email, password)
            )

            user = cursor.fetchone()
            conn.close()

            if user:
                session["user"] = user[1]  # name
                session["role"] = user[4]  # role
                return redirect(url_for("dashboard"))
            else:
                return "Sai email hoặc mật khẩu!"

    return render_template("index.html")


# =============================
# DASHBOARD
# =============================
@app.route("/dashboard")
def dashboard():
    if "user" in session:
        return f"""
        <h1>Xin chào {session['user']}!</h1>
        <p>Role: {session['role']}</p>
        <a href='/logout'>Logout</a>
        """
    else:
        return redirect(url_for("home"))


# =============================
# LOGOUT
# =============================
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


# =============================
# CHẠY APP
# =============================
if __name__ == "__main__":
    init_db()
    app.run(debug=True)